package Exception;

public class seatsAvailableException extends Exception {

		public seatsAvailableException(String message) {
			super(message);
		}
	}

